def sayCheeseLib():
    print("Saying Cheese")

def sayCheeseCheeseLib():
    print("Saying Cheese")

def sayCheeseXTimes(number):
    for x in range(number):
        print("Cheese")

def sayGoodbyeToCheese():
    print("GoodBye <3")

def sayGoodbyeToCheese2():
    print("GoodBye <3 22222")