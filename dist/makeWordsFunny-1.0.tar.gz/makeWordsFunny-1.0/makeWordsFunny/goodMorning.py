def goodMorning():
    print("Good Morning!")

def goodMorningInPolish():
    print("Dzień Dobry")

def goodMorningInFrench():
    print("Bonjour!")

def goodMorningInKorean():
    for i in range(0, 3):
        print("좋은 아침입니다")

def goodMorningTo(name):
    print("Good Morning" + name + " !!")